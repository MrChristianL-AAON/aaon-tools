#!/bin/sh
# Initialization script for Stratus logmanager databases
# This should be run on the first boot by a systemd service, then disable itself.

# NOTE NOTE NOTE: this script should NOT include 'mariadb' in the filename, as we 'pkill mariadb' in the script.  If the script name
# contains 'mariadb' it will match itself and kill itself before it can complete.


set -e

# Create directory if it doesn't exist
mkdir -p /var/stratusdata/mysql
# make mysql the owner
chown mysql:mysql /var/stratusdata/mysql

# Initialize database
mariadb-install-db --user=mysql --datadir=/var/stratusdata/mysql

# Start mysqld_safe in background
mysqld_safe --datadir=/var/stratusdata/mysql --socket=/var/stratusdata/mysql/mysql.sock &

sleep 10

# Run secure installation using expect
expect <<EOF
set timeout 5
spawn mysql_secure_installation --socket=/var/stratusdata/mysql/mysql.sock
expect "Enter current password for root (enter for none):"
send "\r"
expect "Switch to unix_socket authentication?"
send "n\r"
expect "Change the root password?"
send "n\r"
expect "Remove anonymous users?"
send "y\r"
expect "Disallow root login remotely?"
send "y\r"
expect "Remove test database and access to it?"
send "y\r"
expect "Reload privilege tables now?"
send "y\r"
expect eof
EOF

# Run your SQL statements
mysql --socket=/var/stratusdata/mysql/mysql.sock < /etc/init-users.sql

# Stop mysqld_safe
pkill mysqld_safe || true
pkill mariadb || true

# NOTE JPA: trying to place a custom mysqld.service file from mariadb bbappend in meta-cargt

# Fix PIDFile and ExecStart before doing anything else
# sed -i 's|PIDFile=/var/lib/mysql/mysqld.pid|PIDFile=/var/stratusdata/mysql/mysqld.pid|' /lib/systemd/system/mysqld.service
# sed -i 's|ExecStart=/usr/bin/mysqld_safe --basedir=/usr|ExecStart=/usr/bin/mysqld_safe --basedir=/usr --datadir=/var/stratusdata/mysql|' /lib/systemd/system/mysqld.service
# systemctl daemon-reload

# Enable and restart systemd service
systemctl enable mysqld
systemctl restart mysqld

# Optionally, remove this service so it doesn't run again
systemctl disable init-stratusdb.service
