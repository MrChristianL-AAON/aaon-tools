#!/bin/bash

# Directory containing the log files
log_dir="logs/"

# Get unique process names
processes=$(ls $log_dir | grep -oP '^[^_]*' | sort | uniq)

echo "Select a process to view the log:"
select process in $processes; do
  if [ -n "$process" ]; then
    # Find the latest log file for the selected process
    latest_log=$(ls -t $log_dir/${process}_*.log | head -n 1)
    echo "Following the latest log file for $process: $latest_log"
	cat $latest_log
    tail -n 1 -f $latest_log
    break
  else
    echo "Invalid selection. Please try again."
  fi
done
